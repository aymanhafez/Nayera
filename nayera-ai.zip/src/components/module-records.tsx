import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Bot, Loader2, Plus } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { useStartRun } from "@/components/agents/agent-parts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { agentForModule } from "@/data/agents";
import { formFor } from "@/data/module-forms";
import { employees } from "@/data/workspace";
import { supabase } from "@/integrations/supabase/client";
import { useDataSource } from "@/lib/data-source";
import { fetchUploadedEmployees } from "@/lib/uploaded-data";

type Rec = { id: string; module: string; title: string; employee_name: string; details: string; amount: number | null; status: string; created_by: string; run_id: string | null; created_at: string };

export function ModuleRecords({ slug, label, openSignal }: { slug: string; label: string; openSignal: number }) {
  const { source } = useDataSource();
  const agent = agentForModule(slug);
  const { run, pending } = useStartRun();
  const [open, setOpen] = useState(false);
  const [ask, setAsk] = useState("");
  const form = formFor(slug);
  const blank = { title: "", employee: "", amount: "", status: form.statuses[0]! };
  const [f, setF] = useState(blank);
  const [extra, setExtra] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (openSignal) setOpen(true); }, [openSignal]);

  const uploaded = useQuery({ queryKey: ["uploaded-employees"], queryFn: fetchUploadedEmployees, enabled: source === "uploaded" });
  const names = source === "uploaded" ? (uploaded.data ?? []).map((e) => e.name) : employees.map((e) => e.name);

  const recs = useQuery({
    queryKey: ["module-records", slug, source],
    queryFn: async () => {
      const { data, error } = await supabase.from("module_records").select("*").eq("module", slug).eq("data_source", source).order("created_at", { ascending: false }).limit(50);
      if (error) throw error;
      return data as Rec[];
    },
  });
  const [fresh, setFresh] = useState<Set<string>>(new Set());
  const markFresh = (ids: string[]) => {
    if (!ids.length) return;
    setFresh((s) => new Set([...s, ...ids]));
    setTimeout(() => setFresh((s) => { const n = new Set(s); ids.forEach((i) => n.delete(i)); return n; }), 12000);
  };
  useEffect(() => {
    const ch = supabase.channel(`recs-${slug}`).on("postgres_changes", { event: "*", schema: "public", table: "module_records" }, (p) => {
      if (p.eventType === "INSERT" && (p.new as Rec).module === slug) markFresh([(p.new as Rec).id]);
      recs.refetch();
    }).subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]);

  const save = async () => {
    if (!f.title.trim()) { toast.error(`Add ${form.titleLabel.toLowerCase()} first.`); return; }
    const miss = form.fields.find((fd) => fd.required && !extra[fd.key]?.trim());
    if (miss) { toast.error(`${miss.label} is required.`); return; }
    if (extra["start"] && extra["end"] && extra["end"] < extra["start"]) { toast.error("End date must be after start date."); return; }
    setSaving(true);
    const amount = parseFloat(f.amount);
    const details = form.fields.filter((fd) => extra[fd.key]?.trim()).map((fd) => `${fd.label}: ${extra[fd.key]!.trim().slice(0, 1000)}`).join(" · ");
    const { error } = await supabase.from("module_records").insert({
      module: slug, data_source: source, title: f.title.trim().slice(0, 200), employee_name: f.employee, details,
      amount: Number.isFinite(amount) ? amount : null, status: f.status, created_by: "manual",
    });
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Record added");
    setF(blank); setExtra({});
    setOpen(false);
    recs.refetch();
  };

  return (
    <Card className="gap-4 p-4 shadow-[var(--shadow-card)]">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
          <p className="min-w-0 truncate font-display text-sm font-semibold">{label} records</p>
          <Button size="sm" variant={open ? "outline" : "default"} className="gap-1.5" onClick={() => setOpen((o) => !o)}>
          <Plus className="h-3.5 w-3.5" />{open ? "Close" : "Add manually"}
        </Button>
      </div>

      {agent && (
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input value={ask} onChange={(e) => setAsk(e.target.value)} placeholder={`Tell ${agent.name} what to do, e.g. "${agent.starters[0] ?? "create a new record"}"`}
            onKeyDown={(e) => { if (e.key === "Enter") run(ask, agent.id, "High"); }} />
          <Button className="gap-2" disabled={pending || !ask.trim()} onClick={() => run(ask, agent.id, "High")}>
            {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bot className="h-4 w-4" />}Run with agent
          </Button>
        </div>
      )}

      {open && (
        <div className="grid gap-2 rounded-md border border-border p-3 md:grid-cols-2">
          <Field label={`${form.titleLabel} *`}>
            {form.titleOptions ? (
              <Select value={f.title} onValueChange={(v) => setF({ ...f, title: v })}>
                <SelectTrigger><SelectValue placeholder="Choose…" /></SelectTrigger>
                <SelectContent>{form.titleOptions.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
              </Select>
            ) : <Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />}
          </Field>
          {form.employee && (
            <Field label={form.employeeLabel ?? "Employee"}>
              <Select value={f.employee} onValueChange={(v) => setF({ ...f, employee: v })}>
                <SelectTrigger><SelectValue placeholder="Choose…" /></SelectTrigger>
                <SelectContent>{names.map((n) => <SelectItem key={n} value={n}>{n}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
          )}
          {form.fields.map((fd) => (
            <Field key={fd.key} label={`${fd.label}${fd.required ? " *" : ""}`} wide={fd.type === "textarea"}>
              {fd.type === "select" ? (
                <Select value={extra[fd.key] ?? ""} onValueChange={(v) => setExtra({ ...extra, [fd.key]: v })}>
                  <SelectTrigger><SelectValue placeholder="Choose…" /></SelectTrigger>
                  <SelectContent>{fd.options!.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                </Select>
              ) : fd.type === "textarea" ? (
                <Textarea rows={2} value={extra[fd.key] ?? ""} onChange={(e) => setExtra({ ...extra, [fd.key]: e.target.value })} />
              ) : (
                <Input type={fd.type} value={extra[fd.key] ?? ""} onChange={(e) => setExtra({ ...extra, [fd.key]: e.target.value })} />
              )}
            </Field>
          ))}
          {form.amountLabel && (
            <Field label={form.amountLabel}>
              <Input inputMode="decimal" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
            </Field>
          )}
          <Field label="Status">
            <Select value={f.status} onValueChange={(v) => setF({ ...f, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{form.statuses.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Button className="md:col-span-2" disabled={saving} onClick={save}>{saving ? "Saving…" : "Save record"}</Button>
        </div>
      )}

      {(recs.data ?? []).length === 0 ? (
        <p className="text-xs text-muted-foreground">No records yet. Add one manually or ask the agent.</p>
      ) : (
        <ul className="divide-y divide-border">
          {recs.data!.map((r) => (
            <li key={r.id} className={`grid grid-cols-[minmax(0,1fr)_auto] items-start gap-x-2 gap-y-1 rounded-md px-2 py-2 text-sm transition-colors duration-1000 sm:flex sm:flex-wrap sm:items-center ${fresh.has(r.id) ? "bg-primary/15 ring-1 ring-primary" : ""}`}>
              <span className="min-w-0 wrap-break-word font-medium">{r.title}</span>
              {fresh.has(r.id) && <Badge className="text-[10px]">New — agent result</Badge>}
              {r.employee_name && <span className="text-xs text-muted-foreground">· {r.employee_name}</span>}
              {r.amount != null && <span className="text-xs tabular-nums text-muted-foreground">· {r.amount.toLocaleString()}</span>}
              <Badge variant="outline" className="text-[10px]">{r.status}</Badge>
              <span className="col-span-2 text-xs text-muted-foreground sm:ml-auto">
                {r.created_by === "manual" ? "Added manually" : r.run_id ? <Link to="/agents/$runId" params={{ runId: r.run_id }} className="underline">By {r.created_by}</Link> : `By ${r.created_by}`}
              </span>
              {r.details && <p className="w-full text-xs text-muted-foreground">{r.details}</p>}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function Field({ label, wide, children }: { label: string; wide?: boolean; children: React.ReactNode }) {
  return <label className={`min-w-0 space-y-1 text-xs text-muted-foreground ${wide ? "md:col-span-2" : ""}`}><span>{label}</span>{children}</label>;
}
